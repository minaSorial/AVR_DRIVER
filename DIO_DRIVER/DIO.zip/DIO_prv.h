/*
 * DIO_prv.h
 *
 *  Created on: 28 Jul 2023
 *      Author: Mizoo
 */

#ifndef DIO_PRV_H_
#define DIO_PRV_H_


extern const DIO_tstrPIN DIO_kastrPinCg [DIO_PIN_NUM];
extern const DIO_tstrPORT DIO_DIO_kastrPortCg[DIO_PORT_NUM];




#endif /* DIO_PRV_H_ */
