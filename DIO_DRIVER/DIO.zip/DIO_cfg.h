/*
 * DIO_cfg.h
 *
 *  Created on: 28 Jul 2023
 *      Author: Mizoo
 */

#ifndef DIO_CFG_H_
#define DIO_CFG_H_

#define DIO_PIN_NUM 5
#define DIO_PORT_NUM 1


#endif /* DIO_CFG_H_ */
