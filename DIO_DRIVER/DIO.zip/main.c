/*
 * main.c
 *
 *  Created on: 29 Jul 2023
 *      Author: Mizoo
 */


/*
 * main.c
 *
 *  Created on: 27 Jul 2023
 *      Author: Mizoo
 */
#include "std_types.h"
#include "util/delay.h"
#include "DIO_int.h"



int main(void){

	DIO_vidInit();

	while(1){
		//u64 i;

		//u8 status;
		//status=BIT_GET(PINA,7);

		DIO_enuSetPinValue(0,DIO_HIGH);
		_delay_ms(200);

		DIO_enuSetPinValue(0,DIO_LOW);

		_delay_ms(200);

		//elseDIO_enuSetPinValue(0,DIO_HIGH);
			//BIT_CLEAR(PORTA,0);



//		for (i=0 ; i <8000;i++) {
//
//		}

		//PORTA=0B00000000;
		//_delay_ms(500);

//		for (i=0 ; i <8000;i++) {
//
//		}




	}

 return 0;
}

